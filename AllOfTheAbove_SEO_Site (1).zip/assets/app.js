
document.addEventListener('click', (e) => {
  if(e.target.matches('[data-toggle]')){ document.documentElement.classList.toggle('open'); }
});
// Lightbox
(() => {
  const lb = document.getElementById('lightbox');
  const img = document.getElementById('lightbox-img');
  const closeBtn = document.getElementById('lightbox-close');
  if(!lb || !img || !closeBtn) return;
  document.addEventListener('click', (e) => {
    const t = e.target.closest('.thumb img');
    if(!t) return;
    img.src = t.dataset.full || t.src;
    img.alt = t.alt || '';
    lb.classList.add('open');
  });
  const hide = () => { lb.classList.remove('open'); img.removeAttribute('src'); img.removeAttribute('alt'); };
  lb.addEventListener('click', (e) => { if(e.target === lb) hide(); });
  closeBtn.addEventListener('click', hide);
  document.addEventListener('keydown', (e) => { if(e.key === 'Escape') hide(); });
})();
// Fallback for images
document.addEventListener('error', function(e){
  const t = e.target;
  if (t.tagName === 'IMG' && !t.dataset.fallbackTried) {
    t.dataset.fallbackTried = '1';
    if (t.dataset.fallback) t.src = t.dataset.fallback;
  }
}, true);
